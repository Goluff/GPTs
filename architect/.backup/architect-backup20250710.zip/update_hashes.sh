#!/bin/bash

# Files to hash
FILES=(
  architect.yaml
  blackbox-guard.yaml
  experts.yaml
  expert-index-a.yaml
  expert-index-b.yaml
  expert-index-c.yaml
  expert-index-d.yaml
  token-policy.yaml
  ethics.yaml
  self-validation.yaml
  instructions.txt
)

# Backup original metadata.yaml
cp metadata.yaml metadata.yaml.bak

# Create the hashes block
{
  echo "versioning:"
  echo "  generated_at: $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo "  description: File index and hash ledger for integrity checks and audit trail."
  echo ""
  echo "integrity_hashes:"
  for file in "${FILES[@]}"; do
    HASH=$(sha256sum "$file" | awk '{ print $1 }')
    echo "  $file: \"$HASH\""
  done
} > hashes.yaml

# Strip existing versioning/integrity_hashes if present
awk '/^versioning:|^integrity_hashes:/ {exit} {print}' metadata.yaml.bak > metadata.yaml

# Append the new hashes
cat hashes.yaml >> metadata.yaml

# Clean up
rm hashes.yaml
