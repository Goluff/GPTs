 #!/usr/bin/env python3
import argparse
import yaml
import sys
import os

def load_yaml(filepath):
    try:
        with open(filepath, 'r') as f:
            return yaml.safe_load(f)
    except Exception as e:
        sys.exit(f"❌ Failed to parse YAML: {e}")

def validate_yaml(filepath):
    try:
        _ = load_yaml(filepath)
        print("✅ YAML is valid.")
    except Exception as e:
        sys.exit(f"❌ Invalid YAML: {e}")

def extract_fields(data, fields):
    def extract(entry):
        return {k: entry.get(k) for k in fields if k in entry}

    if isinstance(data, list):
        return [extract(item) for item in data]
    elif isinstance(data, dict):
        return extract(data)
    else:
        sys.exit("❌ Unsupported YAML structure.")

def inline_lists(obj):
    if isinstance(obj, list):
        return [inline_lists(item) for item in obj]
    elif isinstance(obj, dict):
        return {k: inline_lists(v) for k, v in obj.items()}
    else:
        return obj

class InlineDumper(yaml.SafeDumper):
    pass

def represent_inline_list(dumper, data):
    if isinstance(data, list) and all(isinstance(i, str) and len(i) <= 50 for i in data):
        return dumper.represent_sequence('tag:yaml.org,2002:seq', data, flow_style=True)
    return dumper.represent_sequence('tag:yaml.org,2002:seq', data)

InlineDumper.add_representer(list, represent_inline_list)

def format_inline(data):
    return yaml.dump(data, Dumper=InlineDumper, sort_keys=False)

def main():
    parser = argparse.ArgumentParser(
        description="YAML Tool — validate YAML, extract fields, or inline lists smartly",
        add_help=False
    )
    parser.add_argument('mode', choices=['validate', 'extract', 'inline'])
    parser.add_argument('yaml_file')
    parser.add_argument('--fields', nargs='+', help="Fields to extract (for 'extract' mode only)")
    parser.add_argument('-h', '--help', action='help', help='Show this help message and exit')

    args = parser.parse_args()

    if not os.path.exists(args.yaml_file):
        sys.exit(f"❌ File not found: {args.yaml_file}")

    data = load_yaml(args.yaml_file)

    if args.mode == 'validate':
        validate_yaml(args.yaml_file)
    elif args.mode == 'extract':
        if not args.fields:
            sys.exit("❌ Please specify --fields field1 field2 ... for extract mode")
        result = extract_fields(data, args.fields)
        print(yaml.dump(result, sort_keys=False))
    elif args.mode == 'inline':
        print(format_inline(inline_lists(data)))

if __name__ == '__main__':
    main()
